Four API v1 effect and behavior recipes. Imported disabled; assign lights before enabling.
